﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_enzo
{
    public partial class FrmAppPratico : Form
    {
        public FrmAppPratico()
        {
            InitializeComponent();
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
            //Pegar os valores na tela
            int qtdPaes = int.Parse(txtp.Text);
            int qtdBroas = int.Parse(txtb.Text);
            float total;

            //Fazer o cálculo
            total = qtdBroas * 1.50f + qtdPaes * 0.12f;

            //Mostrar o resultado em uma label
            lblresultado.Text = "R$" + total;
        }
    }
}
