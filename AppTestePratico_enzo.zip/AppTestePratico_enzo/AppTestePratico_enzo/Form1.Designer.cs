﻿namespace AppTestePratico_enzo
{
    partial class FrmAppPratico
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAppPratico));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblquest1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblvlrpag = new System.Windows.Forms.Label();
            this.btncalc = new System.Windows.Forms.Button();
            this.lblqntdp = new System.Windows.Forms.Label();
            this.txtp = new System.Windows.Forms.TextBox();
            this.txtb = new System.Windows.Forms.TextBox();
            this.lblqntdb = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(158)))), ((int)(((byte)(188)))));
            this.panel1.Controls.Add(this.lblquest1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(802, 122);
            this.panel1.TabIndex = 0;
            // 
            // lblquest1
            // 
            this.lblquest1.AutoSize = true;
            this.lblquest1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquest1.Location = new System.Drawing.Point(11, 9);
            this.lblquest1.Name = "lblquest1";
            this.lblquest1.Size = new System.Drawing.Size(0, 31);
            this.lblquest1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(2)))), ((int)(((byte)(48)))), ((int)(((byte)(71)))));
            this.panel2.Controls.Add(this.lblresultado);
            this.panel2.Controls.Add(this.lblvlrpag);
            this.panel2.Location = new System.Drawing.Point(1, 386);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(802, 67);
            this.panel2.TabIndex = 1;
            // 
            // lblvlrpag
            // 
            this.lblvlrpag.AutoSize = true;
            this.lblvlrpag.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.lblvlrpag.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvlrpag.Location = new System.Drawing.Point(11, 14);
            this.lblvlrpag.Name = "lblvlrpag";
            this.lblvlrpag.Size = new System.Drawing.Size(188, 31);
            this.lblvlrpag.TabIndex = 0;
            this.lblvlrpag.Text = "Valor a pagar";
            // 
            // btncalc
            // 
            this.btncalc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.btncalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalc.Location = new System.Drawing.Point(511, 240);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(164, 75);
            this.btncalc.TabIndex = 2;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = false;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // lblqntdp
            // 
            this.lblqntdp.AutoSize = true;
            this.lblqntdp.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqntdp.Location = new System.Drawing.Point(12, 141);
            this.lblqntdp.Name = "lblqntdp";
            this.lblqntdp.Size = new System.Drawing.Size(284, 31);
            this.lblqntdp.TabIndex = 3;
            this.lblqntdp.Text = "Quantidade de pães:";
            // 
            // txtp
            // 
            this.txtp.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtp.Location = new System.Drawing.Point(18, 175);
            this.txtp.Name = "txtp";
            this.txtp.Size = new System.Drawing.Size(254, 38);
            this.txtp.TabIndex = 4;
            // 
            // txtb
            // 
            this.txtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb.Location = new System.Drawing.Point(18, 274);
            this.txtb.Name = "txtb";
            this.txtb.Size = new System.Drawing.Size(249, 38);
            this.txtb.TabIndex = 5;
            // 
            // lblqntdb
            // 
            this.lblqntdb.AutoSize = true;
            this.lblqntdb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqntdb.Location = new System.Drawing.Point(12, 240);
            this.lblqntdb.Name = "lblqntdb";
            this.lblqntdb.Size = new System.Drawing.Size(279, 31);
            this.lblqntdb.TabIndex = 6;
            this.lblqntdb.Text = "Quantidade de broa:";
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            this.lblresultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresultado.Location = new System.Drawing.Point(211, 14);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(60, 31);
            this.lblresultado.TabIndex = 1;
            this.lblresultado.Text = "R$:";
            // 
            // FrmAppPratico
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblqntdb);
            this.Controls.Add(this.txtb);
            this.Controls.Add(this.txtp);
            this.Controls.Add(this.lblqntdp);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmAppPratico";
            this.Text = "App Padaria";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblquest1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.Label lblqntdp;
        private System.Windows.Forms.TextBox txtp;
        private System.Windows.Forms.TextBox txtb;
        private System.Windows.Forms.Label lblqntdb;
        private System.Windows.Forms.Label lblvlrpag;
        private System.Windows.Forms.Label lblresultado;
    }
}

