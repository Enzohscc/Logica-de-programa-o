﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Logica
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            //Capturar os valores da tela
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float soma;

            //Realizar a soma
            soma = num1 + num3;

            //Mostrar o resultado
            MessageBox.Show("Soma = " + soma);

        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float media;

            //Calcular a média
            media = (num1 + num2 + num3) / 3;

            //Mostrar o resultado
            MessageBox.Show("Media =" + media);
        }

        private void btnporcentagens_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float porc1, porc2, porc3;

            //Cálculos
            porc1 = num1 / (num1 + num2 + num3) * 100;
            porc2 = num2 / (num1 + num2 + num3) * 100;
            porc3 = num3 / (num1 + num2 + num3) * 100;

            //Mostrar resultado
            MessageBox.Show("Porcentagem de número 1 =" + porc1);
            MessageBox.Show("Porcentagem de número 2 =" + porc2);
            MessageBox.Show("Porcentagem de número 3 =" + porc3);
        }
    }
}
