﻿namespace TesteCalculadoraBck
{
    partial class TesteCalc
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TesteCalc));
            this.lblinteiro = new System.Windows.Forms.Label();
            this.lbldecimal = new System.Windows.Forms.Label();
            this.txtdecimal = new System.Windows.Forms.TextBox();
            this.txtinteiro = new System.Windows.Forms.TextBox();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnenviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblinteiro
            // 
            this.lblinteiro.AutoSize = true;
            this.lblinteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinteiro.Location = new System.Drawing.Point(12, 28);
            this.lblinteiro.Name = "lblinteiro";
            this.lblinteiro.Size = new System.Drawing.Size(122, 37);
            this.lblinteiro.TabIndex = 0;
            this.lblinteiro.Text = "Inteiro:";
            // 
            // lbldecimal
            // 
            this.lbldecimal.AutoSize = true;
            this.lbldecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldecimal.Location = new System.Drawing.Point(12, 108);
            this.lbldecimal.Name = "lbldecimal";
            this.lbldecimal.Size = new System.Drawing.Size(149, 37);
            this.lbldecimal.TabIndex = 1;
            this.lbldecimal.Text = "Decimal:";
            // 
            // txtdecimal
            // 
            this.txtdecimal.BackColor = System.Drawing.Color.White;
            this.txtdecimal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdecimal.Location = new System.Drawing.Point(19, 148);
            this.txtdecimal.Name = "txtdecimal";
            this.txtdecimal.Size = new System.Drawing.Size(158, 38);
            this.txtdecimal.TabIndex = 3;
            // 
            // txtinteiro
            // 
            this.txtinteiro.BackColor = System.Drawing.Color.White;
            this.txtinteiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinteiro.Location = new System.Drawing.Point(19, 68);
            this.txtinteiro.Name = "txtinteiro";
            this.txtinteiro.Size = new System.Drawing.Size(158, 38);
            this.txtinteiro.TabIndex = 4;
            // 
            // btnlimpar
            // 
            this.btnlimpar.BackColor = System.Drawing.Color.White;
            this.btnlimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlimpar.Location = new System.Drawing.Point(496, 82);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(130, 47);
            this.btnlimpar.TabIndex = 6;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = false;
            // 
            // btnenviar
            // 
            this.btnenviar.BackColor = System.Drawing.Color.White;
            this.btnenviar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnenviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnenviar.Location = new System.Drawing.Point(341, 82);
            this.btnenviar.Name = "btnenviar";
            this.btnenviar.Size = new System.Drawing.Size(130, 47);
            this.btnenviar.TabIndex = 7;
            this.btnenviar.Text = "Enviar";
            this.btnenviar.UseVisualStyleBackColor = false;
            this.btnenviar.Click += new System.EventHandler(this.btnenviar_Click);
            // 
            // TesteCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Brown;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnenviar);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.txtinteiro);
            this.Controls.Add(this.txtdecimal);
            this.Controls.Add(this.lbldecimal);
            this.Controls.Add(this.lblinteiro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TesteCalc";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblinteiro;
        private System.Windows.Forms.Label lbldecimal;
        private System.Windows.Forms.TextBox txtdecimal;
        private System.Windows.Forms.TextBox txtinteiro;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnenviar;
    }
}

