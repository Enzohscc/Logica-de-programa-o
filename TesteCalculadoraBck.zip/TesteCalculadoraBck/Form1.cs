﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TesteCalculadoraBck
{
    public partial class TesteCalc : Form
    {
        public TesteCalc()
        {
            InitializeComponent();
        }

        private void btnenviar_Click(object sender, EventArgs e)
        {
            int varinteiro = int.Parse(txtinteiro.Text);
            float vardecimal = float.Parse(txtdecimal.Text);
            float resultado;

            //Soma;
            resultado = varinteiro + vardecimal;
            MessageBox.Show("Soma: " + resultado);

            //Subtração;
            resultado = varinteiro - vardecimal;
            MessageBox.Show("Subtração: " + resultado);

            //Multiplicação;
            resultado = varinteiro * vardecimal;
            MessageBox.Show("Multiplicação: " + resultado);

            //Divisão;
            resultado = varinteiro / vardecimal;
            MessageBox.Show("Divisão: " + resultado);

            //Operação mais complexa
            resultado = (2+ varinteiro) / vardecimal + 100;
            MessageBox.Show("Operação mais complexa: " + resultado);


        }
    }
}
